$(document).ready(function () {

    $("#close_message_box").click(function () {
       $("#message_box").hide(1500);
    });

});